<?php

error_reporting(0);
include 'session.php';
if(isset($_SESSION['ID'])){
include 'connectionnn.php';
$gnm=0;
 $sql="select * from messages where user2='$id' and status='sent'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	$gnm++;
}
 $sql="select * from groupmessages where s$id='sent'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	$gnm++;
}
echo $gnm;
}
?>