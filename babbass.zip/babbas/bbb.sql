-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2017 at 08:22 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbb`
--

-- --------------------------------------------------------

--
-- Table structure for table `groupmessages`
--

CREATE TABLE `groupmessages` (
  `frm` varchar(10) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `s111` varchar(10) NOT NULL DEFAULT 'sent',
  `s222` varchar(10) NOT NULL DEFAULT 'sent',
  `s333` varchar(10) NOT NULL DEFAULT 'sent',
  `s444` varchar(10) NOT NULL DEFAULT 'sent',
  `s555` varchar(10) NOT NULL DEFAULT 'sent',
  `s666` varchar(10) NOT NULL DEFAULT 'sent'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `user1` varchar(10) NOT NULL,
  `user2` varchar(10) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'sent',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `num` varchar(12) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `url` varchar(200) NOT NULL DEFAULT 'images/pro.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `pwd`, `num`, `mail`, `url`) VALUES
('111', 'Balram', '211221balu', '7893260228', '', 'images/pro1.jpg'),
('222', 'Chink', '211221chink', '9701099988', '', 'images/pro2.jpg'),
('333', 'CR', '211221cr', '7396494660', '', 'images/pro3.jpg'),
('444', 'Dattu', '211221dattu', '9652278411', '', 'images/pro4.jpg'),
('555', 'Gowtham', '211221gowtham', '9032345039', '', 'images/pro5.jpg'),
('666', 'Navya', '211221navya', '9515878464', '', 'images/pro6.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
