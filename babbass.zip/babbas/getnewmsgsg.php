<?php 
session_start();
error_reporting(0);
if(isset($_SESSION['ID'])){
	?><?php

//error_reporting(0);
include 'session.php';
if(isset($_POST['msgs']) && isset($_SESSION['ID'])){
	$msgs=$_POST['msgs'];
include 'connectionnn.php';
$sql="select * from groupmessages order by time asc";
$res = $conn->query($sql);
echo $conn->error;
$r=$res->num_rows;
$start=$msgs;
$perPage=$r-$msgs;
$query =  $sql . " limit " . $start . "," . $perPage; 
$result = $conn->query($query);
echo $conn->error;
if ($result->num_rows > 0) {
	
		echo '
		<input type="hidden" class="nmsgs" value="' . $r . '" />';
		
	while($row = $result->fetch_assoc())
	{
		$frm=$row['frm'];
		$msg=$row['msg'];
		$time=$row['time'];
		$msgid='';
		$out="";
		if($frm==$id){
			$class1='sentmsg';
			$sname='you';
				$colr='rgba(180,240,180,1)';
				$msgid='seen';
		}
		else{
				$colr='rgba(180,180,240,1)';
			$class1='recmsg';
			if($frm=="111")
				$sname="Balu";
			else if($frm=="222")
				$sname="Chink";
			else if($frm=="333")
				$sname="CR";
			else if($frm=="444")
				$sname="Dattu";
			else if($frm=="555")
				$sname="Gowtham";
			else
				$sname="Navya";
		}
		$out.='<div class="msgbox"><div class="'.$class1.' '.$msgid.'"  style="background-color:'.$colr.';">
		<div class="mhname"><b>'.$sname.'</b></div>
		<div class="msgtext">'.$msg.'</div>
		<div class="time"></div>
		<div class="msgtime" style="display:none;">'.$time.'</div>
		</div></div>';
		print $out;
		
$sql="update groupmessages set s$id='seen' where s$id!='seen'";
$conn->query($sql);
		
	}
	
}


}
?> <?php
}
else
	header('Location:index.php?error=2');
	?>