<?php 
session_start();
error_reporting(0);
if(isset($_SESSION['ID'])){
	?>
<html>
<head> <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

 <title>SnistHub</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<script type="text/javascript" src="js/jquery-3.2.1.js"></script>
<link rel="stylesheet" href="mdl/material.min.css">
<link rel="stylesheet" href="css/notify.css">
<script src="mdl/material.min.js"></script>
<script>
function arc(proid,aorr){
$(document).ready(function(){
    $.ajax({
				type: 'POST' ,
			url: 'msgrequest_arc.php',
			data : {
				proid : proid ,
				check:aorr
			},
			success: function(data){
				location.reload();
			}
		});
});
}


$(document).ready(function(){
	
	setInterval(function(){
	 $.ajax({
			url: 'getnummsgs.php',
			async:false ,
			success: function(data){
				if(data!=0)
					location.reload();
			}
			});
	},3000);
});
function openmsgs(proid,pname){
	window.location='chat_box.php?proid='+proid+'&pname='+pname;
}

</script>
 </head>
  <body>
  <div id="full">
  <div id="ghead"><center><h5>Messages</h5></center></div>
<?php
//error_reporting(0);
session_start();
include 'session.php';
require_once("connectionnn.php");

$sql="
 select * from groupmessages m1 
JOIN 
( 
    select max(time) as time from groupmessages
) m2 
on 
(m1.time=m2.time) 
 ";
$res=$conn->query($sql);
$row = $res->fetch_assoc();
$frm=$row['frm'];
$msg=$row['msg'];
$sta=$row['s'.$id];
            if($frm=="111")
				$lmsg="Balu";
			else if($frm=="222")
				$lmsg="Chink";
			else if($frm=="333")
				$lmsg="CR";
			else if($frm=="444")
				$lmsg="Dattu";
			else if($frm=="555")
				$lmsg="Gowtham";
			else
				$lmsg="Navya";
			if($frm==$id)
				$lmsg='you';
if($sta=='seen')
	$colr='black';
else
	$colr='blue';
 echo '
		<a href="group.php"> <div class="membox">
		 <div class="mdl-js-ripple-effect">
			<div class="memimg"><img src="images/bg.jpg" ></div>
			<div class="memnm" style="color:'.$colr.';">
			<div class="memname">Babbas</div>
			<div class="memmsg">'.$lmsg.' : '.$msg.'</div>
			</div><span class="mdl-ripple"></span>
		 </div>
		 </div></a>';
 $sql="
 select * from messages m1 
JOIN 
( 
    select max(time) as time,user from 
    ( 
        select user2 as user,max(time) as time from `messages` where user1='$id' 
        group by user2 
        union 
        select user1 as user,max(time) as time from `messages` where user2='$id' 
        group by user1 
    ) as t 
    group by user 
    order by time desc
) m2 
on 
(m1.user1=m2.user and m1.user2='$id' and m1.time=m2.time) 
OR 
(m1.user2=m2.user and m1.user1='$id' and m1.time=m2.time)
 ";
 $res=$conn->query($sql);
 echo $conn->error;
	 echo '';
 if($res->num_rows > 0){
	
	 while($row = $res->fetch_assoc()){
		 $proid=$row['user'];
		 $user1=$row['user1'];
		 $msg=$row['msg'];
		 $prosql="select name,url from `users` where id='$proid'";
		 $respro=$conn->query($prosql);
		 $rowpro = $respro->fetch_assoc();
		 $conn->error;
		 $nname=$rowpro['name'];
		 $prourl=$rowpro['url'];
		 $status=$row['status'];
		 $colr='black';
		 if($user1==$proid){
			$lmsg=$nname;
			if($status!='seen'){
				$colr='blue';
			}
		 }
		 else
			$lmsg='you';
		 echo '
		 <div class="membox" onclick=openmsgs("'.$proid.'","'.$nname.'") >
		 <div class="mdl-js-ripple-effect">
			<div class="memimg"><img src="'.$prourl.'" ></div>
			<div class="memnm" style="color:'.$colr.';">
			<div class="memname">'.ucfirst($nname).'</div>
			<div class="memmsg">'.$lmsg.' : '.$msg.'</div>
			</div><span class="mdl-ripple"></span>
		 </div>
		 </div>';
	 }
	 
$sql="update messages set status='delivered' where user2='$id' and status='sent' ";
$conn->query($sql);
$sql="update messages set s$id='delivered' where s$id='sent' ";
$conn->query($sql);
}
 ?>
 
	</div>
<div id="foot" style="background-color:#222244; color:white; font-size:18px; height:30px; padding-top:15px; width:100%; position:fixed; bottom:0;">
<center>Developed by Balram Mitta</center></div>
</body>
  </html>
  <?php
}
else
	header('Location:index.php?error=2');
	?>