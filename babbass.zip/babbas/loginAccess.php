<?php
  
  session_start();
  include 'connectionnn.php';
  if(isset($_POST['las']))
  {
     $b=$_POST['lpw'];	 
	echo $c=$_POST['las'];
$sql = "SELECT * FROM users where name='$c'";
$result = $conn->query($sql);
echo $conn->error;
if ($result->num_rows > 0) {
	echo $row = $result->fetch_assoc();
  if($row['pwd']==$b)
  {   if($c=='Balram')
	  $_SESSION['ID']='111';
      else if($c=='Chink')
		  $_SESSION['ID']='222';
	  else if($c=='CR')
		  $_SESSION['ID']='333';
	  else if($c=='Dattu')
		  $_SESSION['ID']='444';
	  else if($c=='Gowtham')
		  $_SESSION['ID']='555';
	  else
		  $_SESSION['ID']='666';
		  
	  $_SESSION['nn']=$row['name'];
	  $_SESSION['m']=$row['mob'];
	 header('Location:messages.php');
  }
  else{
	  header('Location:index.php?error=4');
  }
} else {
    header('Location:index.php?error=3');
}
  }
?>