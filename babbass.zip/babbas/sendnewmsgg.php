<?php 
session_start();
error_reporting(0);
if(isset($_SESSION['ID'])){
	?><?php

//error_reporting(0);
include 'session.php';
if(isset($_POST['msg']) && isset($_SESSION['ID'])){
	$msg=addslashes($_POST['msg']);
	$msg = str_replace("<", "&lt", $msg);
	$msg = str_replace(">", "&gt", $msg);
include 'connectionnn.php';
$sql="insert into `groupmessages`(`frm`,`msg`) values('$id','$msg')";
$result=$conn->query($sql);
echo $conn->error;
}
?> <?php
}
else
	header('Location:index.php?error=2');
	?>