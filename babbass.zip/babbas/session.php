<?php
session_start();
if(isset($_SESSION['ID']))
{
 $id=$_SESSION['ID'];
 $nn=$_SESSION['nn'];
 $mob=$_SESSION['m'];
}
  
?>