 <html>
 <head>
 <title>SnistHub</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" type="text/css" href="css/ind.css">
<link href='https://fonts.googleapis.com/css?family=Butcherman' rel='stylesheet'>
 
<script type="text/javascript" src="js/jquery-3.2.1.js"></script>
 <script language="javascript" type="text/javascript">
 window.onload = function() {
    document.getElementById("my_audio").play();
}
   window.addEventListener('load', function () {
        var audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        var source = audioCtx.createBufferSource();
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'audio/arb.mp3');
        xhr.responseType = 'arraybuffer';
        xhr.addEventListener('load', function (r) {
            audioCtx.decodeAudioData(
                    xhr.response, 
                    function (buffer) {
                        source.buffer = buffer;
                        source.connect(audioCtx.destination);
                        source.loop = false;
                    });
            source.start(0);
        });
        xhr.send();
    });

</script><script>
</script>
 </head>
 <body>
 <audio id="my_audio" src="audio/arb.mp3" loop="loop"></audio>
 <?php 
 error_reporting(0);
   include 'session.php';
 if(isset($_SESSION["ID"]))
   header('Location:messages.php');
 else
 {
 ?>
    <div id="top">
</div></div>
	<div id="mn">
	<div id="mnl">
	</div>
    <div id="mnr"><?php if(isset($_GET['error']))
		{  echo "Message:";
			if($_GET['error']==3)
				echo "Account with given ID doesn't exist";
			if($_GET['error']==4)
				echo "Incorrect Password";
			if($_GET['error']==2)
				echo "Login first";
			if($_GET['error']==1)
				echo "You have logged out successfully";
			if($_GET['error']==6)
				echo "Password Changed Successfulllly<br>Please Login Again";
			if($_GET['error']==7)
				echo "Error while updating password<br>Please Login and try again";
		 
		}
		?>
	    <form method='post' action='loginAccess.php'><table>
		<tr><th colspan=3 >Login</td></tr>
		
		<tr><td>Login as</td><td>:</td><td><select name="las">
			   <option value="Balram">Balram</option>
			   <option value="Chink">Chink</option>
			   <option value="CR">CR</option>
			   <option value="Dattu">Dattu</option>
			   <option value="Gowtham">Gowtham</option>
			   <option value="Navya">Navya</option>
			   </select>
		</td></tr>
		<tr><td>Password</td><td>:</td><td><input type="password" minlength="6" maxlength="20" name="lpw" placeholder="Enter your password" required></td>
		</tr>
		
		
		<tr><td></td><td></td><td><input type="submit" name="lst" ></td>
		</tr>
		</table>
		</form>
		
	</div>
	</div>
	<?php 
	}
	?>
 </body>
 </html>